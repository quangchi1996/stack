#include<bits/stdc++.h>
//MMASS - Mass of Molecule-spoj 
using namespace std;
ifstream fi;
ofstream fo;
stack<char> hoa;
string s;
long sum=0,sum2=0;
void write()
{
    fo<<sum2;
}
void doc()
{
fi.open("input.inp");
 fi>>s;
}
long kl(char const& a)
{
 if(a=='o') return 16;
 else if(a=='c') return 12;
 return 1;
}
void xuli(string s)
{
 stack<int>kq;
 for(int i=0;i<s.length();++i)
    {
     if(s[i]=='(') kq.push(0);
     if(s[i]>='a'&&s[i]<='z') kq.push(kl(s[i]));
     if((int(s[i])-48)>=2&&(int(s[i])-48<=9)){ int temp=kq.top();kq.pop();kq.push(temp*(int(s[i])-48));};
     if(s[i]==')')
       {
        int sum=0;
        while(kq.top()!=0)
             {
              sum+=kq.top();kq.pop();
             };
        kq.pop();
        kq.push(sum);
       }
    }
 while(!kq.empty())
    {
      sum2+=kq.top();
      kq.pop();    
    }
 write();
}
int main()
{

 doc();
fo.open("kq.out");
xuli(s);
fo.close();
return 0;
}
